/**
 * 地图工具函数
 */

/**
 * 计算两点距离 (Haversine公式, 单位: 米)
 */
function getDistance(lat1, lng1, lat2, lng2) {
  const R = 6371000
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLng = (lng2 - lng1) * Math.PI / 180
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return Math.round(R * c)
}

/**
 * 估算步行时间 (分钟)
 */
function estimateWalkTime(distanceMeters) {
  const speedMetersPerMin = 80
  return Math.max(1, Math.round(distanceMeters / speedMetersPerMin))
}

/**
 * 获取地图标记图标 (根据状态)
 */
function getMarkerIcon(statusColor) {
  const iconMap = {
    green: '/images/toilet-green.png',
    yellow: '/images/toilet-yellow.png',
    red: '/images/toilet-red.png'
  }
  return iconMap[statusColor] || iconMap.green
}

/**
 * 生成地图标记点数据 (用于map组件markers)
 */
function createToiletMarkers(toilets) {
  return toilets.map(t => ({
    id: t.id,
    latitude: t.lat,
    longitude: t.lng,
    width: 36,
    height: 36,
    iconPath: getMarkerIcon(t.status_color),
    callout: {
      content: t.name,
      color: '#333',
      fontSize: 12,
      borderRadius: 8,
      padding: 8,
      display: 'BYCLICK'
    },
    customCallout: {
      anchorY: 0,
      anchorX: 0,
      display: 'BYCLICK'
    },
    // 存储额外数据
    _data: t
  }))
}

/**
 * 生成步行路线点 (polyline)
 */
function createWalkPolyline(from, to) {
  return [{
    points: [
      { latitude: from.lat, longitude: from.lng },
      { latitude: to.entry_lat || to.lat, longitude: to.entry_lng || to.lng }
    ],
    color: '#1A73E8',
    width: 4,
    dottedLine: false,
    arrowLine: true,
    borderColor: '#FFFFFF',
    borderWidth: 1
  }]
}

/**
 * 打开外部导航
 */
function openNavigation(toilet) {
  wx.openLocation({
    latitude: toilet.entry_lat || toilet.lat,
    longitude: toilet.entry_lng || toilet.lng,
    name: toilet.name,
    address: toilet.landmark || '',
    scale: 18
  })
}

/**
 * 获取地图中心偏移 (适配底部卡片)
 */
function getMapCenterOffset(hasBottomCard) {
  return hasBottomCard ? { x: 0, y: -0.3 } : { x: 0, y: 0 }
}

module.exports = {
  getDistance,
  estimateWalkTime,
  getMarkerIcon,
  createToiletMarkers,
  createWalkPolyline,
  openNavigation,
  getMapCenterOffset
}
