// pages/nav/nav.js - 导航引导页逻辑
const api = require('../../utils/api')
const feedbackPage = require('../feedback/feedback')

Page({
  data: {
    toiletName: '',
    toiletId: '',
    steps: [],
    fromFeedback: false
  },

  onLoad(options) {
    const app = getApp()
    const toilet = app.globalData.currentToilet

    if (toilet) {
      this.setData({
        toiletName: toilet.name || '目的地',
        toiletId: toilet.toilet_id || toilet.id
      })
    }

    this.loadNavSteps()
  },

  async loadNavSteps() {
    try {
      const data = await api.getNavSteps(this.data.toiletId)
      this.setData({ steps: data.steps || [] })
    } catch (err) {
      // 默认步骤
      this.setData({
        steps: [
          '导航至IFS商场3号门',
          '进入后找到3号电梯',
          '乘电梯至3楼',
          '出电梯右转',
          '海底捞门口旁通道进入'
        ]
      })
    }
  },

  // 我到了
  onArrive() {
    // 反馈降频检查
    if (!feedbackPage.shouldShowFeedback()) {
      wx.showToast({ title: '已到达目的地', icon: 'success', duration: 1500 })
      setTimeout(() => wx.navigateBack({ delta: 2 }), 1500)
      return
    }

    // 先存储当前厕所信息
    const app = getApp()
    const toilet = app.globalData.currentToilet
    wx.navigateTo({
      url: `/pages/feedback/feedback?id=${toilet ? (toilet.toilet_id || toilet.id) : ''}&from=nav`
    })
  },

  // 直接反馈
  onDirectFeedback() {
    const app = getApp()
    const toilet = app.globalData.currentToilet
    wx.navigateTo({
      url: `/pages/feedback/feedback?id=${toilet ? (toilet.toilet_id || toilet.id) : ''}&from=direct`
    })
  }
})
