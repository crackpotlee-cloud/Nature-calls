// pages/index/index.js - 首页逻辑
const api = require('../../utils/api')
const mapUtil = require('../../utils/map')
const statusUtil = require('../../utils/status')

Page({
  data: {
    mapKey: '', // 腾讯地图key，开发时填写
    latitude: 30.658,
    longitude: 104.082,
    mapScale: 16,
    locationName: '成都 · 春熙路IFS附近',
    markers: [],
    calloutMarkerId: 0,
    calloutName: '',

    // 选中的厕所
    selectedToilet: {
      id: '',
      name: '',
      status_color: 'green',
      walk_time_min: 0
    },
    statusLabel: '可用',
    walkTimeText: '',

    // UI状态
    markerCardVisible: false,
    scenePanelVisible: false,
    loadingVisible: false,

    // 长按计时器
    longPressTimer: null
  },

  onLoad() {
    this.loadNearbyToilets()
  },

  onShow() {
    // 每次回到首页刷新
    this.loadNearbyToilets()
  },

  // 加载附近厕所
  async loadNearbyToilets() {
    try {
      const app = getApp()
      const loc = app.globalData.currentLocation
      this.setData({
        latitude: loc.lat,
        longitude: loc.lng,
        locationName: loc.name
      })

      const data = await api.getNearbyToilets({
        lat: loc.lat,
        lng: loc.lng,
        radius: 2000
      })

      const markers = mapUtil.createToiletMarkers(data.items)
      this.setData({ markers })
    } catch (err) {
      console.error('加载厕所失败:', err)
    }
  },

  // 地图标记点击
  onMarkerTap(e) {
    const markerId = e.detail.markerId
    const marker = this.data.markers.find(m => m.id === markerId)
    if (!marker || !marker._data) return

    const toilet = marker._data
    const statusInfo = statusUtil.getStatusInfo(toilet.status_color)
    
    this.setData({
      selectedToilet: {
        id: toilet.id,
        name: toilet.name,
        status_color: toilet.status_color,
        walk_time_min: toilet.walk_time_min,
        access_type: toilet.access_type
      },
      statusLabel: statusInfo.label,
      walkTimeText: statusUtil.formatWalkTime(toilet.walk_time_min),
      markerCardVisible: true
    })
  },

  // 地图空白区域点击
  onMapTap() {
    if (this.data.markerCardVisible) {
      this.setData({ markerCardVisible: false })
    }
  },

  // 标记卡片点击 → 跳转详情
  onMarkerCardTap() {
    if (this.data.selectedToilet.id) {
      wx.navigateTo({
        url: `/pages/detail/detail?id=${this.data.selectedToilet.id}`
      })
    }
  },

  // 急按钮点击 → 快速搜索
  onEmergencyTap() {
    this.quickSearch('smart')
  },

  // 长按急按钮 → 场景选择
  onEmergencyLongPress() {
    this.setData({ scenePanelVisible: true })
  },

  // 触摸事件（模拟500ms长按）
  onTouchStart() {
    this.data.longPressTimer = setTimeout(() => {
      this.setData({ scenePanelVisible: true })
    }, 500)
  },

  onTouchEnd() {
    clearTimeout(this.data.longPressTimer)
  },

  // 快速搜索（级联搜索：500m → 1000m）
  async quickSearch(scene) {
    this.setData({ loadingVisible: true })
    try {
      const app = getApp()
      const loc = app.globalData.currentLocation

      // 级联搜索：先尝试 500m
      let data = await api.recommendToilet({
        scene,
        lat: loc.lat,
        lng: loc.lng,
        radius: 500,
        top_k: 5
      })

      // 500m 无结果 → 自动扩大至 1000m
      if (!data.recommendations || data.recommendations.length === 0) {
        wx.showToast({ title: '附近厕所较少，已扩大搜索范围', icon: 'none', duration: 2000 })
        data = await api.recommendToilet({
          scene,
          lat: loc.lat,
          lng: loc.lng,
          radius: 1000,
          top_k: 5
        })
      }

      // 1000m 仍无结果 → 提示用户
      if (!data.recommendations || data.recommendations.length === 0) {
        this.setData({ loadingVisible: false })
        wx.showToast({ title: '当前区域暂无厕所数据', icon: 'none', duration: 3000 })
        return
      }

      // 存储推荐结果到全局
      app.globalData.currentScene = scene
      app.globalData.currentRecommendations = data.recommendations
      app.globalData.currentToilet = data.recommendations[0]

      this.setData({ loadingVisible: false })
      
      wx.navigateTo({
        url: '/pages/result/result'
      })
    } catch (err) {
      this.setData({ loadingVisible: false })
      wx.showToast({ title: '搜索失败，请重试', icon: 'none' })
    }
  },

  // 场景选择
  onSelectScene(e) {
    const scene = e.currentTarget.dataset.scene
    this.setData({ scenePanelVisible: false })
    this.quickSearch(scene)
  },

  // 隐藏场景面板
  hideScenePanel() {
    this.setData({ scenePanelVisible: false })
  },

  // 定位按钮
  onLocate() {
    const mapCtx = wx.createMapContext('homeMap')
    mapCtx.moveToLocation()
    wx.showToast({ title: '已定位到当前位置', icon: 'none', duration: 1500 })
  },

  // 贡献厕所
  onAddToilet() {
    wx.navigateTo({
      url: '/pages/contribute/contribute'
    })
  },

  // 分享
  onShareAppMessage() {
    return {
      title: '三急 - 找到最近的厕所',
      path: '/pages/index/index'
    }
  }
})
