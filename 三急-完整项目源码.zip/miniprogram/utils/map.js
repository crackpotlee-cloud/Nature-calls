/**
 * 地图工具函数
 */

/**
 * 计算两点距离 (Haversine公式, 单位: 米)
 */
function getDistance(lat1, lng1, lat2, lng2) {
  const R = 6371000
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLng = (lng2 - lng1) * Math.PI / 180
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return Math.round(R * c)
}

/**
 * 估算步行时间 (分钟)
 */
function estimateWalkTime(distanceMeters) {
  const speedMetersPerMin = 80
  return Math.max(1, Math.round(distanceMeters / speedMetersPerMin))
}

/**
 * 获取地图标记图标 (根据状态)
 */
function getMarkerIcon(statusColor) {
  const iconMap = {
    green: '/images/toilet-green.png',
    yellow: '/images/toilet-yellow.png',
    red: '/images/toilet-red.png'
  }
  return iconMap[statusColor] || iconMap.green
}

/**
 * 生成地图标记点数据 (用于map组件markers)
 */
function createToiletMarkers(toilets) {
  return toilets.map(t => ({
    id: t.id,
    latitude: t.lat,
    longitude: t.lng,
    width: 36,
    height: 36,
    iconPath: getMarkerIcon(t.status_color),
    callout: {
      content: t.name,
      color: '#333',
      fontSize: 12,
      borderRadius: 8,
      padding: 8,
      display: 'BYCLICK'
    },
    customCallout: {
      anchorY: 0,
      anchorX: 0,
      display: 'BYCLICK'
    },
    // 存储额外数据
    _data: t
  }))
}

/**
 * 生成步行路线点 (polyline) - 两点直线（已废弃，请使用 getWalkingRoute）
 * @deprecated
 */
function createWalkPolyline(from, to) {
  return [{
    points: [
      { latitude: from.lat, longitude: from.lng },
      { latitude: to.entry_lat || to.lat, longitude: to.entry_lng || to.lng }
    ],
    color: '#1A73E8',
    width: 4,
    dottedLine: false,
    arrowLine: true,
    borderColor: '#FFFFFF',
    borderWidth: 1
  }]
}

/**
 * 生成模拟步行路径（多拐点折线，至少3-5个中间点）
 * 在起终点之间插入随机偏移点，模拟真实步行路线
 */
function generateMockWalkPoints(fromLat, fromLng, toLat, toLng) {
  const points = [
    { latitude: fromLat, longitude: fromLng }
  ]

  // 计算直线距离
  const dLat = toLat - fromLat
  const dLng = toLng - fromLng

  // 生成3-5个中间拐点
  const midCount = 3 + Math.floor(Math.random() * 3) // 3-5个

  for (let i = 1; i <= midCount; i++) {
    const ratio = i / (midCount + 1)
    // 基本位置在直线上
    let lat = fromLat + dLat * ratio
    let lng = fromLng + dLng * ratio

    // 添加横向偏移模拟转弯（偏移量随距离变化）
    const offset = 0.0003 * (Math.random() - 0.5) * 2
    // 垂直于前进方向的偏移
    const perpLat = -dLng / Math.sqrt(dLat * dLat + dLng * dLng) * offset
    const perpLng = dLat / Math.sqrt(dLat * dLat + dLng * dLng) * offset

    lat += perpLat
    lng += perpLng

    points.push({ latitude: lat, longitude: lng })
  }

  points.push({ latitude: toLat, longitude: toLng })
  return points
}

/**
 * 获取步行路线 - 优先使用腾讯位置服务 direction API，不可用时使用Mock折线
 * @param {Object} from - { lat, lng }
 * @param {Object} to - { lat, lng }
 * @returns {Promise<Array>} polyline 数组
 */
async function getWalkingRoute(from, to) {
  // 优先尝试腾讯位置服务 direction API
  try {
    const route = await fetchWalkingRouteFromTencent(from, to)
    if (route && route.length > 0) return route
  } catch (err) {
    console.log('腾讯步行路线获取失败，使用Mock路径:', err.message || err)
  }

  // Mock模式：使用多拐点折线模拟
  const points = generateMockWalkPoints(from.lat, from.lng, to.lat, to.lng)

  return [{
    points: points,
    color: '#1A73E8',
    width: 4,
    dottedLine: false,
    arrowLine: true,
    borderColor: '#FFFFFF',
    borderWidth: 1
  }]
}

/**
 * 调用腾讯位置服务 walking direction API
 */
function fetchWalkingRouteFromTencent(from, to) {
  return new Promise((resolve, reject) => {
    const app = getApp()
    const skey = app.globalData.mapKey || app.globalData.qqMapKey || ''

    if (!skey) {
      reject(new Error('地图Key未配置'))
      return
    }

    wx.request({
      url: 'https://apis.map.qq.com/ws/direction/v1/walking',
      data: {
        key: skey,
        from: `${from.lat},${from.lng}`,
        to: `${to.lat},${to.lng}`
      },
      success(res) {
        if (res.data && res.data.status === 0 && res.data.result) {
          const route = res.data.result.routes && res.data.result.routes[0]
          if (route && route.polyline) {
            // 腾讯返回的polyline是编码字符串，需要解码
            const coords = []
            // 简单处理：尝试解析坐标数组格式
            // 实际腾讯API返回的polyline可能是压缩格式
            const polylineArr = route.polyline
            if (Array.isArray(polylineArr)) {
              polylineArr.forEach(pt => {
                coords.push({ latitude: pt[0], longitude: pt[1] })
              })
            } else {
              // 尝试用逗号/分号分割解析
              const pts = typeof polylineArr === 'string'
                ? polylineArr.split(';').filter(Boolean)
                : []
              pts.forEach(pt => {
                const parts = pt.split(',').map(Number)
                if (parts.length >= 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
                  coords.push({ latitude: parts[0], longitude: parts[1] })
                }
              })
            }

            if (coords.length > 0) {
              resolve([{
                points: coords,
                color: '#1A73E8',
                width: 4,
                dottedLine: false,
                arrowLine: true,
                borderColor: '#FFFFFF',
                borderWidth: 1
              }])
              return
            }
          }

          // 如果有steps但polyline解析失败，用steps的起终点构造折线
          if (route && route.steps && route.steps.length > 0) {
            const stepPoints = [{ latitude: from.lat, longitude: from.lng }]
            route.steps.forEach(step => {
              if (step.polyline_idx !== undefined) {
                // polyline_idx是索引，我们使用指令文本中的坐标信息作为折点
                // 简化处理：取step的起点作为拐点
                if (step.start_location) {
                  stepPoints.push({
                    latitude: step.start_location.lat,
                    longitude: step.start_location.lng
                  })
                }
              }
            })
            stepPoints.push({ latitude: to.lat, longitude: to.lng })

            resolve([{
              points: stepPoints,
              color: '#1A73E8',
              width: 4,
              dottedLine: false,
              arrowLine: true,
              borderColor: '#FFFFFF',
              borderWidth: 1
            }])
            return
          }
        }

        reject(new Error('腾讯direction API返回无效'))
      },
      fail(err) {
        reject(err)
      }
    })
  })
}

/**
 * 打开外部导航
 */
function openNavigation(toilet) {
  wx.openLocation({
    latitude: toilet.entry_lat || toilet.lat,
    longitude: toilet.entry_lng || toilet.lng,
    name: toilet.name,
    address: toilet.landmark || '',
    scale: 18
  })
}

/**
 * 获取地图中心偏移 (适配底部卡片)
 */
function getMapCenterOffset(hasBottomCard) {
  return hasBottomCard ? { x: 0, y: -0.3 } : { x: 0, y: 0 }
}

module.exports = {
  getDistance,
  estimateWalkTime,
  getMarkerIcon,
  createToiletMarkers,
  createWalkPolyline,
  getWalkingRoute,
  openNavigation,
  getMapCenterOffset
}
