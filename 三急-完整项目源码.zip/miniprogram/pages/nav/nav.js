// pages/nav/nav.js - 导航引导页逻辑
const api = require('../../utils/api')
const mapUtil = require('../../utils/map')
const statusUtil = require('../../utils/status')
const feedbackPage = require('../feedback/feedback')

Page({
  data: {
    mapKey: '',
    latitude: 30.658,
    longitude: 104.082,
    markers: [],
    polyline: [],
    scale: 17,

    toiletName: '',
    toiletId: '',
    steps: [],
    walkTimeText: '',
    statusLabel: '',

    fromFeedback: false
  },

  onLoad(options) {
    const app = getApp()
    const toilet = app.globalData.currentToilet

    if (!toilet) {
      wx.showToast({ title: '未找到厕所信息', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 1500)
      return
    }

    const statusInfo = statusUtil.getStatusInfo(toilet.status_color || toilet.status?.color || 'green')

    this.setData({
      toiletName: toilet.name || '目的地',
      toiletId: toilet.toilet_id || toilet.id,
      walkTimeText: statusUtil.formatWalkTime(toilet.walk_time_min || 0),
      statusLabel: statusInfo.label,
      latitude: toilet.entry_lat || toilet.lat,
      longitude: toilet.entry_lng || toilet.lng
    })

    this.renderMap(toilet)
    this.loadNavSteps()
  },

  // 渲染步行路线地图
  async renderMap(toilet) {
    const app = getApp()
    const userLoc = app.globalData.currentLocation

    // 厕所标记
    const markerLat = toilet.entry_lat || toilet.lat
    const markerLng = toilet.entry_lng || toilet.lng

    const markers = [
      {
        id: 0,
        latitude: markerLat,
        longitude: markerLng,
        width: 36,
        height: 36,
        iconPath: mapUtil.getMarkerIcon(toilet.status_color || 'green'),
        callout: {
          content: toilet.name || '目的地',
          color: '#333',
          fontSize: 12,
          borderRadius: 8,
          padding: 8,
          display: 'ALWAYS'
        }
      }
    ]

    // 步行路线
    const polyline = await mapUtil.getWalkingRoute(
      { lat: userLoc.lat, lng: userLoc.lng },
      { lat: markerLat, lng: markerLng }
    )

    this.setData({ markers, polyline })
  },

  // 加载导航步骤
  async loadNavSteps() {
    try {
      const data = await api.getNavSteps(this.data.toiletId)
      this.setData({ steps: data.steps || [] })
    } catch (err) {
      // 默认步骤
      this.setData({
        steps: [
          '导航至IFS商场3号门',
          '进入后找到3号电梯',
          '乘电梯至3楼',
          '出电梯右转',
          '海底捞门口旁通道进入'
        ]
      })
    }
  },

  // 开始导航 - 调用微信地图
  onStartNav() {
    const app = getApp()
    const toilet = app.globalData.currentToilet
    if (!toilet) return

    mapUtil.openNavigation(toilet)

    // 导航后提示将弹出反馈
    wx.showToast({
      title: '跳转导航后返回将自动弹出反馈',
      icon: 'none',
      duration: 2500
    })
  },

  // 我到了
  onArrive() {
    // 反馈降频检查
    if (!feedbackPage.shouldShowFeedback()) {
      wx.showToast({ title: '已到达目的地', icon: 'success', duration: 1500 })
      setTimeout(() => wx.navigateBack({ delta: 2 }), 1500)
      return
    }

    // 先存储当前厕所信息
    const app = getApp()
    const toilet = app.globalData.currentToilet
    wx.navigateTo({
      url: `/pages/feedback/feedback?id=${toilet ? (toilet.toilet_id || toilet.id) : ''}&from=nav`
    })
  },

  // 直接反馈
  onDirectFeedback() {
    const app = getApp()
    const toilet = app.globalData.currentToilet
    wx.navigateTo({
      url: `/pages/feedback/feedback?id=${toilet ? (toilet.toilet_id || toilet.id) : ''}&from=direct`
    })
  }
})
